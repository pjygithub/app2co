#!/usr/bin/python

  ^!